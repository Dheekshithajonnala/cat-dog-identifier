# Cat-and-Dog-Image-Classifier
We are developing image classification model to distinguish between images of cats and dogs.In this model I've taken a sample dataset from kaggle that contains different images of cats and dogs in two separate folders.

## Libraries used :
Pandas – This library is used to load 2D array format and DataFrames.

Numpy – Numpy library is used to perform large computations in a easier way.

Matplotlib – Matplotlib library  is used to visualize the predictions and models.

Sklearn – Scikit-learn also known as Sklearn library is used to perform tasks from data preprocessing to model development and evaluation.

OpenCV – This OpenCV library  is an open-source library mainly focused on image processing and handling.

Tensorflow – This is an open-source library that is used  to achieve complex functionalities with single lines of code.
